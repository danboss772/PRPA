#include <stdio.h>
 
int main()
{
    printf("Hello PRPA!\n");
    return 0;
}
